package com.example.bankingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingappApplicationTests {

	@Test
	void contextLoads() {
	}

}
