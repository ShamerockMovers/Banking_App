package com.example.bankingapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.bankingapp.Service.AccountService;
import com.example.bankingapp.model.Account;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @PostMapping
    public ResponseEntity<Account> createAccount(@RequestBody Account account) {
        return ResponseEntity.ok(accountService.createAccount(account));
    }

    @GetMapping("/{accountNumber}")
    public ResponseEntity<Account> getAccountDetails(@PathVariable String accountNumber) {
        return ResponseEntity.ok(accountService.getAccountDetails(accountNumber));
    }

    @PostMapping("/{accountNumber}/deposit")
    public ResponseEntity<String> depositAmount(@PathVariable String accountNumber, @RequestParam double amount) {
        accountService.depositAmount(accountNumber, amount);
        return ResponseEntity.ok("Amount deposited successfully");
    }

    @PostMapping("/{accountNumber}/withdraw")
    public ResponseEntity<String> withdrawAmount(@PathVariable String accountNumber, @RequestParam double amount) {
        accountService.withdrawAmount(accountNumber, amount);
        return ResponseEntity.ok("Amount withdrawn successfully");
    }
}
