package com.example.bankingapp.Repository;

import java.util.Optional;

import com.example.bankingapp.model.Account;

public interface AccountRepository {
    Account save(Account account);
    Optional<Account> findById(Long id);
    Optional<Account> findByAccountNumber(String accountNumber);
    void updateBalance(Long id, double newBalance);
}
