package com.example.bankingapp.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.bankingapp.model.Account;

@Repository
public class AccountRepositoryImpl implements AccountRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public Account save(Account account) {
        String sql = "INSERT INTO accounts (account_number, account_holder_name, balance) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, account.getAccountNumber(), account.getAccountHolderName(), account.getBalance());
        return account;
    }

    @Override
    public Optional<Account> findById(Long id) {
        String sql = "SELECT * FROM accounts WHERE id = ?";
        return jdbcTemplate.query(sql, new Object[]{id}, this::mapRowToAccount).stream().findFirst();
    }

    @Override
    public Optional<Account> findByAccountNumber(String accountNumber) {
        String sql = "SELECT * FROM accounts WHERE account_number = ?";
        return jdbcTemplate.query(sql, new Object[]{accountNumber}, this::mapRowToAccount).stream().findFirst();
    }

    @Override
    public void updateBalance(Long id, double newBalance) {
        String sql = "UPDATE accounts SET balance = ? WHERE id = ?";
        jdbcTemplate.update(sql, newBalance, id);
    }

    private Account mapRowToAccount(ResultSet rs, int rowNum) throws SQLException {
        Account account = new Account();
        account.setId(rs.getLong("id"));
        account.setAccountNumber(rs.getString("account_number"));
        account.setAccountHolderName(rs.getString("account_holder_name"));
        account.setBalance(rs.getDouble("balance"));
        return account;
    }
}
