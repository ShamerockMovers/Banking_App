package com.example.bankingapp.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bankingapp.Repository.AccountRepository;
import com.example.bankingapp.exception.AccountNotFoundException;
import com.example.bankingapp.model.Account;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    public Account createAccount(Account account) {
        return accountRepository.save(account);
    }

    public Account getAccountDetails(String accountNumber) {
        return accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new AccountNotFoundException("Account not found"));
    }

    public void depositAmount(String accountNumber, double amount) {
        Account account = getAccountDetails(accountNumber);
        accountRepository.updateBalance(account.getId(), account.getBalance() + amount);
    }

    public void withdrawAmount(String accountNumber, double amount) {
        Account account = getAccountDetails(accountNumber);
        if (account.getBalance() < amount) {
            throw new IllegalArgumentException("Insufficient balance");
        }
        accountRepository.updateBalance(account.getId(), account.getBalance() - amount);
    }
}
